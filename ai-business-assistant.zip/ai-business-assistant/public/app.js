// ─── Landing Page JS ──────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {

  // ─── Mobile Nav Toggle ─────────────────────────────────────────────────────
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.querySelector('.nav-links');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const open = navLinks.style.display === 'flex';
      navLinks.style.display = open ? 'none' : 'flex';
      navLinks.style.flexDirection = open ? '' : 'column';
      navLinks.style.position = open ? '' : 'absolute';
      navLinks.style.top = open ? '' : '68px';
      navLinks.style.left = open ? '' : '0';
      navLinks.style.right = open ? '' : '0';
      navLinks.style.background = open ? '' : 'rgba(7,7,16,.97)';
      navLinks.style.borderBottom = open ? '' : '1px solid #1e1e35';
      navLinks.style.padding = open ? '' : '1rem 1.5rem 1.5rem';
      navLinks.style.gap = open ? '' : '.25rem';
    });
  }

  // ─── Smooth Anchor Scroll ──────────────────────────────────────────────────
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const id = a.getAttribute('href').slice(1);
      const el = document.getElementById(id);
      if (el) {
        e.preventDefault();
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // Close mobile menu if open
        if (navLinks && navLinks.style.display === 'flex' && navLinks.style.position === 'absolute') {
          navLinks.style.display = 'none';
        }
      }
    });
  });

  // ─── Scroll-reveal Animation ───────────────────────────────────────────────
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.feature-card, .step, .pricing-card').forEach(el => {
    el.style.opacity = '0';
    el.style.animation = 'fadeUp .6s ease forwards paused';
    observer.observe(el);
  });

  // ─── Staggered animation delays ────────────────────────────────────────────
  document.querySelectorAll('.feature-card').forEach((el, i) => {
    el.style.animationDelay = `${i * 0.08}s`;
  });
  document.querySelectorAll('.pricing-card').forEach((el, i) => {
    el.style.animationDelay = `${i * 0.1}s`;
  });

  // ─── Sticky Nav Shadow ─────────────────────────────────────────────────────
  const nav = document.querySelector('.nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.style.boxShadow = window.scrollY > 20 ? '0 4px 24px rgba(0,0,0,.4)' : 'none';
    }, { passive: true });
  }
});
